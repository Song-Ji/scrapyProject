import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Record_edit {
    private JPanel panel1;
    private JButton save_Button;
    private JButton exit_Button;
    private JPanel panel2;


    public Record_edit() {
        save_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Scrapy_info instance = new Scrapy_info();
                String table_name = instance.getTable_name();
                JTable data_table = instance.getData_Table();
                Map<JLabel, JTextArea> editMap = instance.getEditMap();
                List<JLabel> list = new ArrayList<JLabel>(editMap.keySet());
//                for(int i= 0; i<list.size();i++){
//                    System.out.println(list.get(i).getText());
//                }
                int columnCount = list.size();
                String database_url = "jdbc:ucanaccess://Database1.accdb";
                try {
                    Connection conn = DriverManager.getConnection(database_url);
                    String sql = "update " + table_name + " set ";
                    for (int i = 0; i < columnCount; i++) {
                        if (i == columnCount - 1) {
                            sql += "published=? where " + list.get(0).getText() + "=?";
                        } else {
                            sql += list.get(i).getText() + "=?, ";
                        }
                    }
                    System.out.println(sql);
                    // 预置对象, 设置占位符值
                    PreparedStatement preparedStatement = conn.prepareStatement(sql);
                    for (int i = 0; i < columnCount; i++) {
                        if (i == columnCount - 1) {
                            if (editMap.get(list.get(i)).getText().equals("true")) {
                                preparedStatement.setInt(i + 1, -1);
                            } else {
                                preparedStatement.setInt(i + 1, 0);
                            }
                        } else {
                            preparedStatement.setString(i + 1, editMap.get(list.get(i)).getText());
                        }

                    }
                    preparedStatement.setString(columnCount + 1, editMap.get(list.get(0)).getText());
                    /**执行sql语句， 返回影响的行数**/
                    int res = preparedStatement.executeUpdate();
                    if (res > 0) {
                        System.out.println("更新数据成功");
                    }
                    for (int i = 0; i < columnCount; i++) {
                        data_table.setValueAt(editMap.get(list.get(i)).getText(), data_table.getSelectedRow(), i);
                    }
                    instance.getEditFrame().dispose();
                    preparedStatement.close();
                    conn.close();
                } catch (SQLException exception) {
                    exception.printStackTrace();
                }
            }
        });
        exit_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Scrapy_info instance = new Scrapy_info();
                instance.getEditFrame().dispose();
            }
        });
    }

    public JPanel getPanel1() {
        return panel1;
    }
}
