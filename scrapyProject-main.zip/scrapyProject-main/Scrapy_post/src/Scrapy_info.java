import org.apache.commons.io.FileUtils;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.sql.*;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Vector;

public class Scrapy_info {
    private JPanel main_panel;
    private JPanel second_panel;
    private JLabel collect_Label;
    private JLabel publishTo_Label;
    private JLabel url_Label;
    private JLabel from_Label;
    private JButton start_Button;
    private JButton check_Button;
    private JButton add_modify_Button;
    private JLabel scrapy_info_Label;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JButton add_Button;
    private JButton edit_Button;
    private JButton delete_Button;
    private JToolBar jToolBar;
    private JPanel third_panel;
    private String new_file_path;
    private int saved_data;
    private int key = 1;
    private Scrapy_progress instance;
    private RandomAccessFile randomAccessFile;
    private boolean a = true;
    private int progressbarNum;
    private Integer count;
    private boolean b = true;
    private int i = 0;
    private int columnCount;
    private JLabel jLabel;
    private JTextArea jTextArea;
    private JScrollPane jScrollPane;
    private JFrame scrapy_progress_Frame;
    private JTable data_Table;
    private DefaultTableModel tableModel;
    private String table_name;
    private Map<Integer, JProgressBar> barMap;

    public Scrapy_info(){
        check_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jToolBar.setVisible(true);
                edit_Button.setEnabled(false);
                delete_Button.setEnabled(false);
                String Label = scrapy_info_Label.getText();
                String ID = Label.substring(0, 1);
                String database_url = "jdbc:ucanaccess://Database1.accdb";
                try {
                    Connection conn = DriverManager.getConnection(database_url);
                    Statement st = conn.createStatement();
                    String sql = "select table_name from scrapy_script_record where id = " + ID;
                    ResultSet rs = st.executeQuery(sql);
                    while (rs.next()){
                        table_name = rs.getString(1);
                        System.out.println(table_name);
                    }
                    String sql_2 = "select * from " + table_name;
                    rs = st.executeQuery(sql_2);

                    // names of columns
                    Vector<String> columnNames = new Vector<>();
                    columnCount = rs.getMetaData().getColumnCount();
                    for(int column = 1; column <= columnCount; column++){
                        columnNames.add(rs.getMetaData().getColumnName(column));
                    }

                    // data of the table
                    Vector<Vector<Object>> data = new Vector<>();
                    while (rs.next()){
                        Vector<Object> vector = new Vector<>();
                        for(int columnIndex = 1; columnIndex <= columnCount; columnIndex++){
                            vector.add(rs.getObject(columnIndex));
                        }
                        data.add(vector);
                    }
                    tableModel = new DefaultTableModel(data, columnNames);
                    data_Table = new JTable(tableModel);
                    data_Table.setFillsViewportHeight(true);
                    data_Table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
                        @Override
                        public void valueChanged(ListSelectionEvent e) {
                            edit_Button.setEnabled(true);
                            delete_Button.setEnabled(true);
                        }
                    });
                    jScrollPane = new JScrollPane(data_Table);
                    third_panel.removeAll();
                    third_panel.add(jScrollPane, BorderLayout.CENTER);
                    third_panel.revalidate();
                    third_panel.repaint();
                    rs.close();
                    st.close();
                    conn.close();
                    } catch (SQLException exception) {
                        exception.printStackTrace();
                    }
            }
        });
        add_modify_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();
                chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
                chooser.showDialog(scrapy_progress_Frame, "选择");
                File file = chooser.getSelectedFile();
                String file_name = file.getName();
                String sp = System.getProperty("user.dir");
                new_file_path = sp + "\\" + file_name;
                try {
                    FileUtils.copyFileToDirectory(file, new File(System.getProperty("user.dir")));
                    start_Button.setBackground(Color.GREEN);
                    start_Button.setEnabled(true);
                } catch (IOException fileNotFoundException) {
                    fileNotFoundException.printStackTrace();
                }
            }
        });
        start_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                create_Progress_Frame();
                new Thread(new MyRunnable()).start();
            }
        });
        add_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                create_Record_add_Frame();
            }
        });
        delete_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 方法1：JTable 删除选中的一行或者多行
                int[] rows = data_Table.getSelectedRows();
                String database_url = "jdbc:ucanaccess://Database1.accdb";
                try {
                    Connection conn = DriverManager.getConnection(database_url);
                    Statement st = conn.createStatement();
                    for (int row : rows) {
                        String sql = "delete from " + table_name + " where " + data_Table.getColumnName(0) + " = " + "'" + data_Table.getValueAt(row, 0).toString() + "'";
                        System.out.println(table_name);
                        st.executeUpdate(sql);
                    }
                    st.close();
                    conn.close();
                } catch (SQLException exception) {
                    exception.printStackTrace();
                }
                for(int i = rows.length - 1; i>=0; i--){
                    tableModel.removeRow(rows[i]);
                }
                delete_Button.setEnabled(false);
                edit_Button.setEnabled(false);
                /*
 方法2：JTable 删除选中的一行或者多行
                int rows = data_Table.getSelectedRows().length;
                for(int i=0; i<rows;i++){
                    tableModel.removeRow(data_Table.getSelectedRow());
                }
*/
            }
        });
        edit_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                create_Record_edit_Frame();
            }
        });
    }

    public void create_Record_add_Frame(){
        int column_count = data_Table.getColumnCount();
        JPanel jPanel = new JPanel(new GridLayout(column_count, 2));
        Map<JLabel, JTextArea> addMap = new LinkedHashMap<>();
        for(int i=0; i<column_count; i++){
            String column_name = data_Table.getColumnName(i);
            jTextArea = new JTextArea();
            jTextArea.setLineWrap(true);
            if(i == column_count - 1){
                jLabel = new JLabel(column_name + "(文本只接受true/false)");
            }
            else {
                jLabel = new JLabel(column_name);
            }
            addMap.put(jLabel, jTextArea);
            jScrollPane = new JScrollPane(jTextArea);
            jPanel.add(jLabel);
            jPanel.add(jScrollPane);
        }
        JFrame record_add_Frame = new JFrame("记录添加");
        record_add_Frame.setLocation(300, 300);
        record_add_Frame.setSize(800, 600);
        Record_add record_add = new Record_add(table_name, tableModel, addMap, record_add_Frame);
        record_add.getPanel1().add(jPanel, BorderLayout.CENTER);
        record_add_Frame.setContentPane(record_add.getPanel1());
        record_add_Frame.setVisible(true);
    }

    private void create_Progress_Frame() {
        scrapy_progress_Frame = new JFrame("爬虫进度");
        scrapy_progress_Frame.setLocation(300, 300);
        scrapy_progress_Frame.setSize(1000, 800);
        instance = new Scrapy_progress(scrapy_progress_Frame);
        instance.getFinish_ButtonButton().setEnabled(false);
        scrapy_progress_Frame.setContentPane(instance.getPanel());
        scrapy_progress_Frame.setVisible(true);
        barMap = new HashMap<>();
        String cmd = "python " + new_file_path;
        try {
            Runtime.getRuntime().exec(cmd);
            File file = new File("log.txt");
            Thread.sleep(5000);
            while (true) {
                if (file.exists()) {
                    randomAccessFile = new RandomAccessFile("log.txt", "r");
                    randomAccessFile.seek(0);
                    System.out.println("文件已经存在");
                    break;
                }
            }
            while (a) {
                try {
                    BufferedReader in = new BufferedReader(new FileReader("log.txt"));
                    String str;
                    while ((str = in.readLine()) != null) {
                        if (str.contains("一共采集")) {
                            System.out.println(str);
                            String[] parts = str.split(" ");
                            String parts2 = parts[1];
                            count = Integer.parseInt(parts2);
                            progressbarNum = (int) Math.ceil(count / 10.0);
                            a = false;
                            break;
                        }
                    }
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            Integer counter = count;
            for (int cc = 1; cc <= progressbarNum; cc++) {
                JProgressBar jProgressBar = new JProgressBar();
                jProgressBar.setValue(0);
                if (cc == progressbarNum) {
                    jProgressBar.setString("完成一共" + counter.toString() + "条数据采集，本次采集结束");

                } else {
                    jProgressBar.setString("完成10条数据采集");
                }
                jProgressBar.setStringPainted(true);
                instance.getSecond_panel().add(jProgressBar);
                barMap.put(cc, jProgressBar);
                scrapy_progress_Frame.revalidate();
            }
    } catch (IOException | InterruptedException ioException) {
            ioException.printStackTrace();
        }
    }

    public void create_Record_edit_Frame(){
        int row = data_Table.getSelectedRow();
        int column_count = data_Table.getColumnCount();
        JPanel jPanel = new JPanel(new GridLayout(column_count,2));
        Map<JLabel, JTextArea> editMap = new LinkedHashMap<>();
        for(int i=0; i<column_count; i++) {
            String column_name = data_Table.getColumnName(i);
            String cell_value = data_Table.getValueAt(row, i).toString();
            jTextArea = new JTextArea();
            jTextArea.setText(cell_value);
            jTextArea.setLineWrap(true);
            if(i == column_count - 1){
                jLabel = new JLabel(column_name + "(文本只接受true/false)");
            }
            else {
                jLabel = new JLabel(column_name);
            }
            editMap.put(jLabel, jTextArea);
            JScrollPane scrollPane = new JScrollPane(jTextArea);
            jPanel.add(jLabel);
            jPanel.add(scrollPane);
        }
        JFrame record_edit_Frame = new JFrame("记录编辑");
        record_edit_Frame.setLocation(300, 300);
        record_edit_Frame.setSize(800, 600);
        Record_edit record_edit = new Record_edit(table_name, data_Table, editMap, record_edit_Frame);
        record_edit.getPanel1().add(jPanel, BorderLayout.CENTER);
        record_edit_Frame.setContentPane(record_edit.getPanel1());
        record_edit_Frame.setVisible(true);
    }

    private void fill() throws InterruptedException, IOException {
        String tmp;
        while ((tmp = randomAccessFile.readLine()) != null) {
            String line = new String(tmp.getBytes(StandardCharsets.ISO_8859_1));
//            System.out.println(line);
            if (line.equals("数据保存成功")) {
                saved_data++;
                if (saved_data > 10) {
                    saved_data = 1;
                    key++;
                    i = 0;
                }
                i += 10;
                barMap.get(key).setValue(i);
            }
            if (line.equals("采集结束")) {
                barMap.get(key).setValue(100);
                b = false;
                instance.getFinish_ButtonButton().setEnabled(true);
                break;
            }
        }
        long lastTimeFilePointer = randomAccessFile.getFilePointer();
        randomAccessFile.seek(lastTimeFilePointer);
    }

    private class MyRunnable implements Runnable{
        @Override
        public void run() {
            while (b) {
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            fill();
                        } catch (InterruptedException | IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public JPanel getMainPanel(){
        return main_panel;
    }
    public JLabel getScrapy_info_Label(){
        return scrapy_info_Label;
    }
    public JTextField getTextField1(){
        return  textField1;
    }
    public JTextField getTextField2(){
        return textField2;
    }
    public JTextField getTextField3(){
        return textField3;
    }
    public JTextField getTextField4(){
        return textField4;
    }
    public JButton getStart_Button(){
        return start_Button;
    }
    public JToolBar getJToolBar(){
        return  jToolBar;
    }
}


