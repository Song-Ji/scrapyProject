import org.apache.commons.io.FileUtils;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

public class Scrapy_info {
    private JPanel main_panel;
    private JPanel second_panel;
    private JButton start_Button;
    private JButton check_Button;
    private JButton add_modify_Button;
    private JLabel scrapy_info_Label;
    private JLabel collect_Label;
    private JLabel publishTo_Label;
    private JLabel url_Label;
    private JLabel from_Label;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JButton add_Button;
    private JButton edit_Button;
    private JButton delete_Button;
    private JTable data_Table;
    private DefaultTableModel tableModel;
    private JPanel loading_panel;
    private String newfilePath;
    private static JFrame scrapy_progress_Frame;
    private int saved_data;
    private int key = 1;
    private Scrapy_progress instance;
    private RandomAccessFile randomAccessFile;
    private boolean a = true;
    private int progressbarNum;
    private Integer count;
    private Map<Integer, JProgressBar> barMap;
    private boolean b = true;
    private int i = 0;
    private Task task;
    private Object[] row;
    private int columnCount;

    public Scrapy_info(){
        check_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(scrapy_info_Label.getText().contains("1")){
                    try {
                        test instance = new test();
                        String database_url = "jdbc:ucanaccess://Database1.accdb";
                        Connection conn = DriverManager.getConnection(database_url);
                        Statement st = conn.createStatement();
                        String sql = "select * from big_news";
                        ResultSet rs = st.executeQuery(sql);

                        // names of columns
                        Vector<String> columnNames = new Vector<String>();
                        columnCount = rs.getMetaData().getColumnCount();
                        for(int column = 1; column <= columnCount; column++){
                            columnNames.add(rs.getMetaData().getColumnName(column));
                        }

                        // data of the table
                        Vector<Vector<Object>> data = new Vector<Vector<Object>>();
                        while (rs.next()){
                            Vector<Object> vector = new Vector<Object>();
                            for(int columnIndex = 1; columnIndex <= columnCount; columnIndex++){
                                vector.add(rs.getObject(columnIndex));
                            }
                            data.add(vector);
                        }
                        tableModel = new DefaultTableModel(data, columnNames);
                        data_Table = new JTable(tableModel);
                        JTabbedPane tabbedPane = new JTabbedPane();
                        JScrollPane panel = new JScrollPane(data_Table);
                        data_Table.setFillsViewportHeight(true);
                        JPanel panel2 = new JPanel();
                        JPanel panel3 = new JPanel();
                        tabbedPane.addTab("Tab 1", panel);
                        tabbedPane.addTab("Tab 2", panel2);
                        tabbedPane.addTab("Tab 3", panel3);
                        main_panel.add(tabbedPane, BorderLayout.CENTER);
                        instance.getScrapy_info_Frame().pack();
                        instance.getScrapy_info_Frame().setVisible(true);

                    } catch (SQLException exception) {
                        exception.printStackTrace();
                    }
                }
            }
        });
        delete_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 方法1：JTable 删除选中的一行或者多行
                int[] rows = data_Table.getSelectedRows();
                for(int i = rows.length - 1; i>=0; i--){
                    tableModel.removeRow(rows[i]);
                }
                /*
 方法2：JTable 删除选中的一行或者多行
                int rows = data_Table.getSelectedRows().length;
                for(int i=0; i<rows;i++){
                    tableModel.removeRow(data_Table.getSelectedRow());
                }
*/
            }
        });
        add_modify_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();
                chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
                chooser.showDialog(scrapy_progress_Frame, "选择");
                File file = chooser.getSelectedFile();
                String file_name = file.getName();
                String sp = System.getProperty("user.dir");
                newfilePath = sp + "\\" + file_name;
                try {
                    FileUtils.copyFileToDirectory(file, new File(System.getProperty("user.dir")));
                    start_Button.setBackground(Color.GREEN);
                    start_Button.setEnabled(true);
                } catch (IOException fileNotFoundException) {
                    fileNotFoundException.printStackTrace();
                }
            }
        });
        start_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createScrapyProgressFrame();
                createScrapyProgressBar();

                task = new Task();
                task.start();
            }
        });
        add_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                row = new Object[columnCount];
                tableModel.addRow(row);
            }
        });
    }

    private class Task extends Thread{
        public Task(){
        }
        public void run(){
            while (b) {
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            fill();
                        } catch (InterruptedException | IOException e) {
                            e.printStackTrace();
                        }
                    }
                });
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    private void createScrapyProgressBar() {
        barMap = new HashMap<>();
        String cmd = "python " + newfilePath;
        try {
            Process proc = Runtime.getRuntime().exec(cmd);
            File file = new File("log.txt");
            Thread.sleep(5000);
            while (true) {
                if (file.exists()) {
                    randomAccessFile = new RandomAccessFile("log.txt", "r");
                    randomAccessFile.seek(0);
                    System.out.println("文件已经存在");
                    break;
                }
            }
            while (a) {
                try {
                    BufferedReader in = new BufferedReader(new FileReader("log.txt"));
                    String str;
                    while ((str = in.readLine()) != null) {
                        if (str.contains("一共采集")) {
                            System.out.println(str);
                            String[] parts = str.split(" ");
                            String parts2 = parts[1];
                            count = Integer.parseInt(parts2);
                            progressbarNum = (int) Math.ceil(count / 10.0);
                            a = false;
                            break;
                        }
                    }
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            int progress = progressbarNum;
            Integer counter = count;
            for (int cc = 1; cc <= progress; cc++) {
                JProgressBar jProgressBar = new JProgressBar();
                jProgressBar.setValue(0);
                if (cc == progress) {
                    jProgressBar.setString("完成一共" + counter.toString() + "条数据采集，本次采集结束");

                } else {
                    jProgressBar.setString("完成10条数据采集");
                }
                jProgressBar.setStringPainted(true);
                instance.getSecond_panel().add(jProgressBar);
                barMap.put(cc, jProgressBar);
                scrapy_progress_Frame.setVisible(true);
            }
    } catch (IOException | InterruptedException ioException) {
            ioException.printStackTrace();
        }
    }

    private void createScrapyProgressFrame() {
        scrapy_progress_Frame = new JFrame("爬虫进度");
        scrapy_progress_Frame.setLocation(300, 300);
        scrapy_progress_Frame.setSize(1000, 800);
        instance = new Scrapy_progress();
        instance.getButton().setEnabled(false);
        scrapy_progress_Frame.setContentPane(instance.getPanel());
        scrapy_progress_Frame.setVisible(true);
    }

    private void fill() throws InterruptedException, IOException {
        String tmp;
        while ((tmp = randomAccessFile.readLine()) != null) {
            String line = new String(tmp.getBytes("ISO-8859-1"));
//            System.out.println(line);
            if (line.equals("数据保存成功")) {
                saved_data++;
                if (saved_data > 10) {
                    saved_data = 1;
                    key++;
                    i = 0;
                }
                i += 10;
                barMap.get(key).setValue(i);
            }
            if (line.equals("采集结束")) {
                barMap.get(key).setValue(100);
                b = false;
                instance.getButton().setEnabled(true);
                break;
            }
        }
        long lastTimeFilePointer = randomAccessFile.getFilePointer();
        randomAccessFile.seek(lastTimeFilePointer);
    }

    public JTable getData_Table(){
        return data_Table;
    }
    public JPanel getMainPanel(){
        return main_panel;
    }
    public JLabel getScrapy_info_Label(){
        return scrapy_info_Label;
    }
    public JTextField getTextField1(){
        return  textField1;
    }
    public JTextField getTextField2(){
        return textField2;
    }
    public JTextField getTextField3(){
        return textField3;
    }
    public JTextField getTextField4(){
        return textField4;
    }
    public JFrame getFrame(){
        return scrapy_progress_Frame;
    }
    public JButton getStart_Button(){
        return start_Button;
    }

}
