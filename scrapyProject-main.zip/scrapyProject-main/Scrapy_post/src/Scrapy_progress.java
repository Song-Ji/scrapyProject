import javax.swing.*;

public class Scrapy_progress {
    private JPanel panel;
    private JButton button1;
    private JPanel second_panel;


    public JPanel getPanel(){
        return panel;
    }

    public JPanel getSecond_panel(){
        return second_panel;
    }

}
