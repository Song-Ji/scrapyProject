import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Scrapy_progress {
    private JPanel panel;
    private JButton Button;
    private JPanel second_panel;


    public Scrapy_progress() {
        Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Scrapy_info instance = new Scrapy_info();
                instance.getFrame().dispose();
            }
        });
    }

    public JPanel getPanel(){
        return panel;
    }

    public JPanel getSecond_panel(){
        return second_panel;
    }

    public JButton getButton(){
        return Button;
    }

}
