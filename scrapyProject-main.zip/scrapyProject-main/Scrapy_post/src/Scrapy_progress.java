import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Scrapy_progress {
    private JPanel panel;
    private JButton finish_Button;
    private JPanel second_panel;


    public Scrapy_progress(JFrame scrapy_progress_Frame) {
        finish_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                scrapy_progress_Frame.dispose();
            }
        });
    }

    public JPanel getPanel(){
        return panel;
    }

    public JPanel getSecond_panel(){
        return second_panel;
    }

    public JButton getFinish_ButtonButton(){
        return finish_Button;
    }

}
