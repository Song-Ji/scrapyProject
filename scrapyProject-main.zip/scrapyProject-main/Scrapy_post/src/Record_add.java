import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Vector;

public class Record_add {
    private JPanel panel_1;
    private JButton add_Button;
    private JButton exit_Button;
    private JPanel panel_2;


    public Record_add(String table_name, DefaultTableModel tableModel, Map<JLabel, JTextArea> addMap, JFrame record_add_Frame) {
        add_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Vector<String> vector = new Vector<>();
                // put Labels into List
                List<JLabel> list = new ArrayList<>(addMap.keySet());
                int columnCount = list.size();
                String database_url = "jdbc:ucanaccess://Database1.accdb";
                try {
                    Connection conn = DriverManager.getConnection(database_url);
                    StringBuilder column_names = new StringBuilder("(");
                    StringBuilder values = new StringBuilder(" VALUES(");
                    for (int i = 0; i < columnCount; i++) {
                        if (i == columnCount - 1) {
                            column_names.append("published)");
                            values.append("?)");
                        } else {
                            column_names.append(list.get(i).getText()).append(",");
                            values.append("?,");
                        }
                    }
                    String sql = "INSERT INTO " + table_name + column_names + values;
                    System.out.println(sql);
                    // 预置对象, 设置占位符值
                    PreparedStatement preparedStatement = conn.prepareStatement(sql);
                    for (int i = 0; i < columnCount; i++) {
                        if (i == columnCount - 1) {
                            if (addMap.get(list.get(i)).getText().equals("true")) {
                                preparedStatement.setInt(i + 1, -1);
                            } else {
                                preparedStatement.setInt(i + 1, 0);
                            }
                        } else {
                            preparedStatement.setString(i + 1, addMap.get(list.get(i)).getText());
                        }
                    }
                    /*执行sql语句， 返回影响的行数**/
                    int res = preparedStatement.executeUpdate();
                    if (res > 0) {
                        System.out.println("添加数据成功");
                    }
                    for (JLabel jLabel : list) {
                        vector.add(addMap.get(jLabel).getText());
                    }
                    tableModel.addRow(vector);
                    record_add_Frame.dispose();
                    preparedStatement.close();
                    conn.close();
                } catch (SQLException exception) {
                    exception.printStackTrace();
                }
            }
        });
        exit_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                record_add_Frame.dispose();
            }
        });
    }
    public JPanel getPanel1() {
        return panel_1;
    }
}
