import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Scrapy_post {
    private static JFrame scrapy_post_Frame;
    private JButton collect_Button;
    private JButton publish_Button;
    private JPanel scrapy_post_Panel;
    private JButton article_Button;
    private JButton forum_Button;


    public Scrapy_post() {
        collect_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Article_forum article_forum = new Article_forum();
                JPanel article_forum_panel = article_forum.getPanel();
                JLabel article_forum_label = article_forum.getLabel();
//                article_forum.setLabel("采集：");
                article_forum_label.setText("采集：");
                scrapy_post_Frame.setContentPane(article_forum_panel);
                scrapy_post_Frame.pack();
                scrapy_post_Frame.setVisible(true);
            }
        });
        publish_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Article_forum article_forum = new Article_forum();
                JPanel article_forum_panel = article_forum.getPanel();
                JLabel article_forum_label = article_forum.getLabel();
                article_forum_label.setText("发布：");
                scrapy_post_Frame.setContentPane(article_forum_panel);
                scrapy_post_Frame.pack();
                scrapy_post_Frame.setVisible(true);
            }
        });
    }

    public JFrame getFrame(){
        return scrapy_post_Frame;
    }

    public JPanel getPanel(){
        return scrapy_post_Panel;
    }

    public static void main(String[] args){
        scrapy_post_Frame = new JFrame("scrapy_post_system");
        scrapy_post_Frame.setLocation(600, 600);
        scrapy_post_Frame.setPreferredSize(new Dimension(800, 600));
        scrapy_post_Frame.setContentPane(new Scrapy_post().scrapy_post_Panel);
        scrapy_post_Frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        scrapy_post_Frame.pack();
        scrapy_post_Frame.setVisible(true);


    }


    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
