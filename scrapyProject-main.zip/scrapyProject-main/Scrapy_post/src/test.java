import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.sql.*;

public class test {
    private JPanel main_panel;
    private JButton collect_Button;
    private JButton publish_Button;
    private JButton user_Button;
    private JButton setting_Button;
    private JButton add_Button;
    private JPanel second_panel;
    private JPanel scrapy_panel;
    private JTabbedPane tabbedPane;
    public static JFrame post_info_Frame;

    public test() {
        collect_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                add_Button.setVisible(true);
                scrapy_panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
                String database_url = "jdbc:ucanaccess://Database1.accdb";
                try {
                    Connection conn = DriverManager.getConnection(database_url);
                    Statement st = conn.createStatement();
                    String sql = "select * from scrapy_script_record";
                    ResultSet rs = st.executeQuery(sql);
                    while (rs.next()){
                        String ID = rs.getString(1);
                        String from = rs.getString(2);
                        String collect = rs.getString(3);
                        String publishTo = rs.getString(4);
                        String url = rs.getString(5);
                        String script_name = rs.getString(6);
                        JButton scrapy_script = new JButton(from+" 爬虫");
                        scrapy_panel.add(scrapy_script);
                        scrapy_script.addActionListener(new ActionListener(){
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                createScrapyInfoFrame(ID, from, collect, publishTo, url, script_name);
                            }
                        });
                    }
                    rs.close();
                    st.close();
                    conn.close();
                    second_panel.removeAll();
                    second_panel.add(scrapy_panel, BorderLayout.CENTER);
                    second_panel.revalidate();
                    second_panel.repaint();
                } catch (SQLException exception) {
                    exception.printStackTrace();
                }
            }
        });
        publish_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                add_Button.setVisible(false);
                tabbedPane = new JTabbedPane();
                JPanel post_news_panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
                JPanel post_forum_panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
                tabbedPane.addTab("News", post_news_panel);
                tabbedPane.addTab("Forum", post_forum_panel);
                String database_url = "jdbc:ucanaccess://Database1.accdb";
                try {
                    Connection conn = DriverManager.getConnection(database_url);
                    DatabaseMetaData md = conn.getMetaData();
                    ResultSet rs = md.getTables(null, null, "%", null);
                    while(rs.next()){
                        String table_name = rs.getString(3);
//                        System.out.println(rs.getString(3));
                        if(table_name.contains("news")){
                            JButton post_Button = new JButton(table_name);
                            post_news_panel.add(post_Button);
                            post_Button.addActionListener(new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent e) {
                                    createPostInfoFrame(table_name, table_name + "_post.py");
                                }
                            });
                        }
                        if(table_name.contains("forum")){
                            JButton post_table = new JButton(table_name);
                            post_forum_panel.add(post_table);
                            post_table.addActionListener(new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent e) {
                                    createPostInfoFrame(table_name, table_name + "_post.py");

                                }
                            });
                        }
                    }
                    rs.close();
                    conn.close();
                    second_panel.removeAll();
                    second_panel.add(tabbedPane, BorderLayout.CENTER);
                    second_panel.revalidate();
                    second_panel.repaint();
                } catch (SQLException exception) {
                    exception.printStackTrace();
                }
            }
        });
    }

    private void createPostInfoFrame(String table_name, String post_script_name){
        post_info_Frame = new JFrame("发布信息");
        post_info_Frame.setLocation(300, 300);
        post_info_Frame.setSize(800, 600);
        Post_info instance = new Post_info();
        instance.getJLabel_table_name().setText(table_name + " 表");
        instance.getCheck_Button().setVisible(true);
        instance.getAdd_Button().setVisible(false);
        instance.getDelete_Button().setVisible(false);
        instance.getEdit_Button().setVisible(false);
        instance.getPost_Button().setVisible(false);
        File file = new File(post_script_name);
        if(file.isFile()){
            instance.getPost_Button().setText("发布");
            instance.getPost_Button().setForeground(Color.GREEN);
        }
        else {
            instance.getPost_Button().setText("添加发布脚本");
        }
        post_info_Frame.setContentPane(instance.getFirst_panel());
        post_info_Frame.setVisible(true);
    }

    private void createScrapyInfoFrame(String ID, String from, String collect, String publishTo, String url, String script_name){
        JFrame scrapy_info_Frame = new JFrame("爬虫信息");
        scrapy_info_Frame.setLocation(300, 300);
        scrapy_info_Frame.setSize(800, 600);
        Scrapy_info instance = new Scrapy_info();
        instance.getJToolBar().setVisible(false);
        instance.getScrapy_info_Label().setText(ID +". "+ from + " 爬虫信息");
        instance.getTextField1().setText(from);
        instance.getTextField2().setText(collect);
        instance.getTextField3().setText(publishTo);
        instance.getTextField4().setText(url);
        File file = new File(script_name);
        if(file.isFile()){
            instance.getStart_Button().setOpaque(true);
            instance.getStart_Button().setBackground(Color.GREEN);
            instance.getStart_Button().setEnabled(true);
        }
        else {
            instance.getStart_Button().setOpaque(true);
            instance.getStart_Button().setBackground(Color.GRAY);
            instance.getStart_Button().setEnabled(false);
        }
        scrapy_info_Frame.setContentPane(instance.getMainPanel());
        scrapy_info_Frame.setVisible(true);
    }


    public static void main(String[] args) {
        test instance = new test();
        instance.add_Button.setVisible(false);
        JFrame test_Frame = new JFrame("scrapy_post_system");
        test_Frame.setLocation(300, 300);
        test_Frame.setSize(800, 600);
        test_Frame.setContentPane(instance.main_panel);
        test_Frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        test_Frame.setVisible(true);
    }
}
