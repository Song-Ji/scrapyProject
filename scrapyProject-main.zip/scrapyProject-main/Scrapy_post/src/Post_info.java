import org.apache.commons.io.FileUtils;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Vector;

public class Post_info {
    private JPanel first_panel;
    private JPanel second_panel;
    private JButton check_Button;
    private JButton add_Button;
    private JButton edit_Button;
    private JButton delete_Button;
    private JButton post_Button;
    private JLabel jLabel_table_name;
    private JLabel jLabel_column_name;
    private DefaultTableModel tableModel;
    private JTable data_Table;
    private String table_name;
    private Record_add record_add;
    private Record_edit record_edit;
    private Map<JLabel, JTextArea> addMap;
    private Map<JLabel, JTextArea> editMap;
    private JTextArea jTextArea;
    private String post_script_path;

    public Post_info() {
        check_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                add_Button.setVisible(true);
                edit_Button.setVisible(true);
                delete_Button.setVisible(true);
                edit_Button.setEnabled(false);
                delete_Button.setEnabled(false);
                post_Button.setVisible(true);
                String Label = jLabel_table_name.getText();
                table_name = Label.split(" ")[0];
                String database_url = "jdbc:ucanaccess://Database1.accdb";
                try {
                    Connection conn = DriverManager.getConnection(database_url);
                    Statement st = conn.createStatement();
                    String sql = "select * from " + table_name;
                    ResultSet rs = st.executeQuery(sql);

                    // names of columns
                    Vector<String> columnNames = new Vector<>();
                    int columnCount = rs.getMetaData().getColumnCount();
                    for(int column = 1; column <= columnCount; column++){
                        columnNames.add(rs.getMetaData().getColumnName(column));
                    }

                    // data of the table
                    Vector<Vector<Object>> data = new Vector<>();
                    while (rs.next()){
                        Vector<Object> vector = new Vector<>();
                        for(int columnIndex = 1; columnIndex <= columnCount; columnIndex++){
                            vector.add(rs.getObject(columnIndex));
                        }
                        data.add(vector);
                    }
                    tableModel = new DefaultTableModel(data, columnNames);
                    data_Table = new JTable(tableModel);
                    data_Table.setFillsViewportHeight(true);
                    data_Table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
                        @Override
                        public void valueChanged(ListSelectionEvent e) {
                            edit_Button.setEnabled(true);
                            delete_Button.setEnabled(true);
                        }
                    });
                    JScrollPane jScrollPane = new JScrollPane(data_Table);
                    second_panel.removeAll();
                    second_panel.add(jScrollPane, BorderLayout.CENTER);
                    second_panel.revalidate();
                    second_panel.repaint();
                    rs.close();
                    st.close();
                    conn.close();
                } catch (SQLException exception) {
                    exception.printStackTrace();
                }
            }
        });
        add_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                create_Record_add_Frame();
            }
        });
        edit_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                create_Record_edit_Frame();
            }
        });
        delete_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 方法1：JTable 删除选中的一行或者多行
                int[] rows = data_Table.getSelectedRows();
                String database_url = "jdbc:ucanaccess://Database1.accdb";
                try {
                    Connection conn = DriverManager.getConnection(database_url);
                    Statement st = conn.createStatement();
                    for (int row : rows) {
                        String sql = "delete from " + table_name + " where " + data_Table.getColumnName(0) + " = " + "'" + data_Table.getValueAt(row, 0).toString() + "'";
                        st.executeUpdate(sql);
                    }
                    st.close();
                    conn.close();
                } catch (SQLException exception) {
                    exception.printStackTrace();
                }
                for(int i = rows.length - 1; i>=0; i--){
                    tableModel.removeRow(rows[i]);
                }
                delete_Button.setEnabled(false);
                edit_Button.setEnabled(false);
            }
        });
        post_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(post_Button.getText().equals("发布")){
                    String sp = System.getProperty("user.dir");
                    post_script_path = sp + "\\" + table_name + "_post.py";
                    String cmd = "python " + post_script_path;
                    try {
                        Runtime.getRuntime().exec(cmd);
                    } catch (IOException ioException) {
                        ioException.printStackTrace();
                    }
                }
                else {
                    JFileChooser chooser = new JFileChooser();
                    chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
                    chooser.showDialog(null, "选择");
                    File file = chooser.getSelectedFile();
                    String file_name = file.getName();
                    if(file_name.equals(table_name + "_post.py")){
                        try {
                            FileUtils.copyFileToDirectory(file, new File(System.getProperty("user.dir")));
//                            String sp = System.getProperty("user.dir");
//                            post_script_path = sp + "\\" + file_name;
                            post_Button.setText("发布");
                            post_Button.setForeground(Color.GREEN);
                        } catch (IOException fileNotFoundException) {
                            fileNotFoundException.printStackTrace();
                        }
                    }
                }
            }
        });
    }

    private void create_Record_edit_Frame() {
        int row = data_Table.getSelectedRow();
        int column_count = data_Table.getColumnCount();
        JPanel jPanel = new JPanel(new GridLayout(column_count,2));
        editMap = new LinkedHashMap<>();
        for(int i=0; i<column_count; i++) {
            String column_name = data_Table.getColumnName(i);
            String cell_value = data_Table.getValueAt(row, i).toString();
            jTextArea = new JTextArea();
            jTextArea.setText(cell_value);
            jTextArea.setLineWrap(true);
            jLabel_column_name = new JLabel();
            if(i == column_count - 1){
                jLabel_column_name.setText(column_name + "(文本只接受true/false)");
            }
            else {
                jLabel_column_name.setText(column_name);
            }
            editMap.put(jLabel_column_name, jTextArea);
            JScrollPane scrollPane = new JScrollPane(jTextArea);
            jPanel.add(jLabel_column_name);
            jPanel.add(scrollPane);
        }
        JFrame record_edit_Frame = new JFrame("记录编辑");
        record_edit_Frame.setLocation(300, 300);
        record_edit_Frame.setSize(800, 600);
        record_edit = new Record_edit(table_name, data_Table, editMap, record_edit_Frame);
        record_edit.getPanel1().add(jPanel, BorderLayout.CENTER);
        record_edit_Frame.setContentPane(record_edit.getPanel1());
        record_edit_Frame.setVisible(true);
    }

    public void create_Record_add_Frame(){
        int column_count = data_Table.getColumnCount();
        JPanel jPanel = new JPanel(new GridLayout(column_count, 2));
        addMap = new LinkedHashMap<>();
        for(int i=0; i<column_count; i++){
            String column_name = data_Table.getColumnName(i);
            jTextArea = new JTextArea();
            jTextArea.setLineWrap(true);
            if(i == column_count - 1){
                jLabel_column_name = new JLabel(column_name + "(文本只接受true/false)");
            }
            else {
                jLabel_column_name = new JLabel(column_name);
            }
            addMap.put(jLabel_column_name, jTextArea);
            JScrollPane jScrollPane = new JScrollPane(jTextArea);
            jPanel.add(jLabel_column_name);
            jPanel.add(jScrollPane);
        }
        JFrame record_add_Frame = new JFrame("记录添加");
        record_add_Frame.setLocation(300, 300);
        record_add_Frame.setSize(800, 600);
        record_add = new Record_add(table_name, tableModel, addMap, record_add_Frame);
        record_add.getPanel1().add(jPanel, BorderLayout.CENTER);
        record_add_Frame.setContentPane(record_add.getPanel1());
        record_add_Frame.setVisible(true);
    }

    public JPanel getFirst_panel(){
        return first_panel;
    }
    public JButton getCheck_Button(){
        return check_Button;
    }
    public JButton getAdd_Button(){
        return add_Button;
    }
    public JButton getEdit_Button(){
        return edit_Button;
    }
    public JButton getDelete_Button(){
        return delete_Button;
    }
    public JButton getPost_Button(){
        return post_Button;
    }
    public JLabel getJLabel_table_name(){
        return jLabel_table_name;
    }
}
