import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class unittest {
    private static JFrame scrapy_progress_Frame;
    private JPanel panel1;
    private JButton button1;
    private JPanel second_panel;


    public unittest() {
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                scrapy_progress_Frame.dispose();
            }
        });
    }

    public static void main(String[] args) throws IOException {
//        RandomAccessFile randomAccessFile = new RandomAccessFile("new.txt", "r");
//        randomAccessFile.seek(0);
//        String tmp = "";
////        tmp = randomAccessFile.readLine();
////        System.out.println(new String(tmp.getBytes("ISO-8859-1")));
//        String cc = "dwdw";
//        while((tmp = randomAccessFile.readLine())!=null){
//            String str  = new String(tmp.getBytes("ISO-8859-1"));
//            System.out.println(new String(tmp.getBytes("ISO-8859-1")));
//            if(str.equals("寄送")){
//                break;
//            }
//            System.out.println(tmp);
////            System.out.println(tmp.length());
//        }
////        try {
////            BufferedReader in = new BufferedReader(new FileReader("new.txt"));
////            String str;
////            while ((str = in.readLine()) != null) {
////                    System.out.println(str);
////            }
////        } catch (IOException e) {
////        }
//        Long lastTimeFileSize = randomAccessFile.getFilePointer();
//        System.out.println(lastTimeFileSize);
////        randomAccessFile.seek(cc.length());
////        Long lastTimeFileSize = randomAccessFile.length();
////        System.out.println(lastTimeFileSize);
//
////        Map<Integer, JProgressBar> barMap = new HashMap<Integer, JProgressBar>();
////        unittest instance = new unittest();
        scrapy_progress_Frame = new JFrame("爬虫进度");
        scrapy_progress_Frame.setLocation(300, 300);
        scrapy_progress_Frame.setSize(800, 600);
//        for (int cc = 1; cc <= 5; cc++) {
//            if (cc == 5) {
//                JProgressBar jProgressBar = new JProgressBar();
//                jProgressBar.setValue(0);
//                jProgressBar.setString("完成一共条数据采集，本次采集结束");
//                jProgressBar.setStringPainted(true);
//                instance.second_panel.add(jProgressBar);
//                barMap.put(cc, jProgressBar);
//            } else {
//                JProgressBar jProgressBar = new JProgressBar();
//                jProgressBar.setValue(0);
//                jProgressBar.setString("完成10条数据采集");
//                jProgressBar.setStringPainted(true);
//                instance.second_panel.add(jProgressBar);
//                barMap.put(cc, jProgressBar);
//            }
        scrapy_progress_Frame.setContentPane(new unittest().panel1);
//            scrapy_progress_Frame.pack();
        scrapy_progress_Frame.setVisible(true);
//        }
    }
}

