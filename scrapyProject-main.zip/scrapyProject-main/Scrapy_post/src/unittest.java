import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class unittest {
    private static JFrame scrapy_progress_Frame;
    private JPanel panel1;
    private JButton button1;
    private JPanel second_panel;


    public unittest() {
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                scrapy_progress_Frame.dispose();
            }
        });
    }

    public static void main(String[] args) throws IOException {
        JFrame frame = new JFrame("GridLayout Test");
        JLabel label = new JLabel("title");
        JLabel label2 = new JLabel("content");
        JTextField jTextField = new JTextField();
        JTextArea jTextArea = new JTextArea("dwdwdwdddddddddddddddddddddddddddd");
        jTextArea.setLineWrap(true);
        JScrollPane scrollPane = new JScrollPane(jTextArea);
        frame.add(label);
        frame.add(jTextField);
        frame.add(label2);
        frame.add(scrollPane);
        frame.setLayout(new GridLayout(2,2));
        frame.setSize(300,300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}

