import javax.swing.*;

public class record_edit {
    private JPanel panel1;
}
