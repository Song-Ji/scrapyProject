import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Scrapy_post_frame extends JFrame{
    private JButton button1;
    private  JButton button2;
    private JPanel jPnael;


    public Scrapy_post_frame(String title, int x, int y, int width, int height) {
        this.setTitle(title);
        this.setLocation(x, y);
        Scrapy_post_panel scrapy_post_panel = new Scrapy_post_panel();
        scrapy_post_panel.setPreferredSize(new Dimension(width, height));
        scrapy_post_panel.requestFocusInWindow();
        Container visibleArea = this.getContentPane();
        visibleArea.add(scrapy_post_panel);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane();
        this.pack();


    }

    public static void main(String[] args){

        Scrapy_post_frame jFrame = new Scrapy_post_frame("scrapy_post_system", 100, 100, 400, 400);
        jFrame.setVisible(true);





    }


}

class Scrapy_post_panel extends JPanel{


}
