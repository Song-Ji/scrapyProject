import javax.swing.*;

public class article_forum {
    private JButton button1;
    private JPanel panel1;
    private JButton button2;
    private JButton button3;
    private JButton button4;

    public JPanel getPanel(){
        return this.panel1;
    }


}
