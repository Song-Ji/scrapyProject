import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Scrapy_post {
    private JButton collect_Button;
    private JButton publish_Button;
    private JPanel jPanel;


    public Scrapy_post() {
        collect_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
    }

    public static void main(String[] args){
        JFrame jFrame = new JFrame("scrapy_post_system");
        jFrame.setLocation(100, 100);
        jFrame.setPreferredSize(new Dimension(400, 400));
        jFrame.setContentPane(new Scrapy_post().jPanel);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.pack();
        jFrame.setVisible(true);


    }


}
