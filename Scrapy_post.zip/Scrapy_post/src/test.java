import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class test {
    private JPanel main_panel;
    private JButton collect_Button;
    private JButton publish_Button;
    private JButton user_Button;
    private JButton setting_Button;
    private JButton add_Button;
    private JPanel second_panel;
    private static JFrame test_Frame;
    private static JFrame scrapy_info_Frame;

    public test() {
        collect_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
//                second_panel.setVisible(true);
                JPanel third_panel = new JPanel();
                third_panel.setLayout(new FlowLayout());
                second_panel.add(third_panel, BorderLayout.WEST);
                try {
                    String database_url = "jdbc:ucanaccess://D:/Download/Database1.accdb";
                    Connection conn = DriverManager.getConnection(database_url);
                    Statement st = conn.createStatement();
                    String sql = "select * from scrapy_script_record";
                    ResultSet rs = st.executeQuery(sql);
                    while (rs.next()){
                        String ID = rs.getString(1);
                        System.out.println(ID);
                        String from = rs.getString(2);
                        String collect = rs.getString(3);
                        String publishTo = rs.getString(4);
                        String url = rs.getString(5);
                        String script_url = rs.getString(6);
                        JButton scrapy_script = new JButton(from+" 爬虫");
                        third_panel.add(scrapy_script);
                        scrapy_script.addActionListener(new ActionListener(){
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                createScrapyInfoFrame(ID, from, collect, publishTo, url, script_url);
                            }
                        });
                        test_Frame.revalidate();
                    }
                } catch (SQLException exception) {
                    exception.printStackTrace();
                }
            }
        });
    }

    public void createScrapyInfoFrame(String ID, String from, String collect, String publishTo, String url, String script_url){
        scrapy_info_Frame = new JFrame("爬虫信息");
        scrapy_info_Frame.setLocation(300, 300);
//        frame.setSize(800, 600);
        Scrapy_info instance = new Scrapy_info();
        instance.getScrapy_info_Label().setText(from + " 爬虫信息 " + ID + "   ");
        instance.getTextField1().setText(from);
        instance.getTextField2().setText(collect);
        instance.getTextField3().setText(publishTo);
        instance.getTextField4().setText(url);
        instance.getTextField5().setText(script_url);
        Scrapy_info cc = new Scrapy_info();
        String s =  cc.getTextField3().getText();

        System.out.println(instance.getTextField3().getText());
//        instance.getMainPanel().add(tabbedPane, BorderLayout.CENTER);
//        panel.add(instance.getData_Table());
        scrapy_info_Frame.setContentPane(instance.getMainPanel());
        scrapy_info_Frame.pack();
        scrapy_info_Frame.setVisible(true);

    }


    public static void main(String[] args) throws SQLException {
        test instance = new test();
        test_Frame = new JFrame("scrapy_post_system");
        test_Frame.setLocation(400, 400);
        test_Frame.setSize(800, 600);
//        test_Frame.setPreferredSize(new Dimension(800, 600));
        test_Frame.setContentPane(instance.main_panel);
        test_Frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        test_Frame.pack();
        test_Frame.setVisible(true);

    }

    public JPanel getMainPanel(){
        return main_panel;
    }
    public JPanel getSecondPanel(){
        return second_panel;
    }
    public JFrame getScrapy_info_Frame(){
        return scrapy_info_Frame;
    }

}
