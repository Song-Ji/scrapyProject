import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Websites {
    private JPanel websites_Panel;
    private JButton googleNews_Button;
    private JButton skykiwi_Button;
    private JButton park_Button;
    private JButton back_to_previous_page_Button;
    private JButton back_to_home_page_Button;
    private JLabel websites_Label;
    private Boolean isRunning = false;

    public Websites() {
        back_to_previous_page_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Scrapy_post scrapy_post = new Scrapy_post();
                Article_forum article_forum = new Article_forum();
                JLabel article_forum_Label = article_forum.getLabel();
//                System.out.println(websites_Label.getText());
                if(websites_Label.getText().contains("采集")){
                    article_forum_Label.setText("采集：");
                }
                else{
                    article_forum_Label.setText("发布：");
                }
                JFrame scrapy_post_Frame = scrapy_post.getFrame();
                scrapy_post_Frame.setContentPane(article_forum.getPanel());
                scrapy_post_Frame.pack();
                scrapy_post_Frame.setVisible(true);
            }
        });
        back_to_home_page_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Scrapy_post scrapy_post = new Scrapy_post();
                JFrame scrapy_post_Frame = scrapy_post.getFrame();
                scrapy_post_Frame.setContentPane(scrapy_post.getPanel());
                scrapy_post_Frame.pack();
                scrapy_post_Frame.setVisible(true);
            }
        });
        skykiwi_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(!isRunning){
                    isRunning = true;
                    if(websites_Label.getText().contains("采集")){

//                    String file_path = "D:\\Download\\scrapy_skykiwi_forum.py";
                        String file_path = "D:\\Download\\hello.py";
                        String cmd = "python " + file_path;
                        try {
                            Process proc = Runtime.getRuntime().exec(cmd);
//                        proc.waitFor()
                            InputStreamReader inputStreamReader = new InputStreamReader(proc.getInputStream(), "GBK");
                            BufferedReader input = new BufferedReader(inputStreamReader);

                            String line = null;
                            while((line = input.readLine()) != null){
                                System.out.println(line);
                            }
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    }
                    else{
                        String file_path = "D:\\Download\\scrapy_skykiwi_forum_post.py";
                        String cmd = "python " + file_path;
                        try {
                            Process proc = Runtime.getRuntime().exec(cmd);
                        } catch (IOException ioException) {
                            ioException.printStackTrace();
                        }
                    }
                }
                else{
                    Scrapy_post scrapy_post = new Scrapy_post();
                    JFrame scrapy_post_Frame = scrapy_post.getFrame();
                    JOptionPane.showMessageDialog(scrapy_post_Frame, "脚本正在运行，请勿重复点击！");
                }
            }
        });
        park_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(websites_Label.getText().contains("采集")){
                    String file_path = "D:\\Download\\scrapy.py";
                    String cmd = "python " + file_path;
                    try {
                        Process proc = Runtime.getRuntime().exec(cmd);
                    } catch (IOException ioException) {
                        ioException.printStackTrace();
                    }
                }
                else{
                    String file_path = "D:\\Download\\scrapy_post.py";
                    String cmd = "python " + file_path;
                    try {
                        Process proc = Runtime.getRuntime().exec(cmd);
                    } catch (IOException ioException) {
                        ioException.printStackTrace();
                    }
                }
            }
        });
        googleNews_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(websites_Label.getText().contains("采集")){
                    String file_path = "D:\\Download\\scrapy_local_news.py";
                    String cmd = "python " + file_path;
                    try {
                        Process proc = Runtime.getRuntime().exec(cmd);
                    } catch (IOException ioException) {
                        ioException.printStackTrace();
                    }
                }
                else{
                    String file_path = "D:\\Download\\scrapy_local_news_post.py";
                    String cmd = "python " + file_path;
                    try {
                        Process proc = Runtime.getRuntime().exec(cmd);
                    } catch (IOException ioException) {
                        ioException.printStackTrace();
                    }
                }
            }
        });
    }

    public JPanel getPanel(){
        return websites_Panel;
    }
    public JLabel getLabel(){
        return websites_Label;
    }
    public JButton getParkButton(){
        return park_Button;
    }
    public JButton getGoogleNewsButton(){
        return googleNews_Button;
    }
    public JButton getSkykiwiButton(){
        return skykiwi_Button;
    }
}
