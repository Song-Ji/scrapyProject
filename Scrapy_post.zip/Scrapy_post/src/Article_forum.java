import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Article_forum {
    private JPanel panel;
    private JButton article_Button;
    private JButton forum_Button;
    private JButton back_Button;
    private JLabel article_forum_Label;

    public Article_forum() {
        back_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Scrapy_post scrapy_post = new Scrapy_post();
                JFrame scrapy_post_Frame = scrapy_post.getFrame();
                scrapy_post_Frame.setContentPane(scrapy_post.getPanel());
                scrapy_post_Frame.pack();
                scrapy_post_Frame.setVisible(true);
            }
        });
        article_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Scrapy_post scrapy_post = new Scrapy_post();
                Websites websites = new Websites();
                JLabel websites_label = websites.getLabel();
//                JButton park_Button = websites.getParkButton();
//                park_Button.setVisible(false);
//                JButton googleNews_Button = websites.getGoogleNewsButton();
//                googleNews_Button.setVisible(false);
                JButton skykiwi_Button = websites.getSkykiwiButton();
                skykiwi_Button.setVisible(false);
                if(article_forum_Label.getText().equals("采集：")){
                    websites_label.setText("采集文章，点击选择文章抓取网站：");
                }
                else{
                    websites_label.setText("发布文章，点击选择文章来源网站：");
                }
                JFrame scrapy_post_Frame = scrapy_post.getFrame();
                scrapy_post_Frame.setContentPane(websites.getPanel());
                scrapy_post_Frame.pack();
                scrapy_post_Frame.setVisible(true);
            }
        });
        forum_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Scrapy_post scrapy_post = new Scrapy_post();
                Websites websites = new Websites();
                JLabel websites_label = websites.getLabel();
                JButton park_Button = websites.getParkButton();
                park_Button.setVisible(false);
                JButton googleNews_Button = websites.getGoogleNewsButton();
                googleNews_Button.setVisible(false);
                if(article_forum_Label.getText().equals("采集：")){
                    websites_label.setText("采集论坛，点击选择论坛抓取网站：");
                }
                else{
                    websites_label.setText("发布论坛，点击选择论坛来源网站：");
                }
                JFrame scrapy_post_Frame = scrapy_post.getFrame();
                scrapy_post_Frame.setContentPane(websites.getPanel());
                scrapy_post_Frame.pack();
                scrapy_post_Frame.setVisible(true);
            }
        });
    }

    public JPanel getPanel(){
        return this.panel;
    }
    public JLabel getLabel(){
        return article_forum_Label;
    }


}
