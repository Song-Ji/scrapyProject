import javax.swing.*;
import javax.swing.table.DefaultTableColumnModel;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;

public class Scrapy_info {
    private JPanel main_panel;
    private JPanel second_panel;
    private JButton start_Button;
    private JButton check_Button;
    private JButton add_modify_Button;
    private JLabel scrapy_info_Label;
    private JLabel collect_Label;
    private JLabel publishTo_Label;
    private JLabel url_Label;
    private JLabel from_Label;
    private JLabel script_url;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JTextField textField5;
    private JTable data_Table;

    public Scrapy_info(){

        check_Button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(scrapy_info_Label.getText().contains("1")){
                    try {
                        test instance = new test();
                        String database_url = "jdbc:ucanaccess://D:/Download/Database1.accdb";
                        Connection conn = DriverManager.getConnection(database_url);
                        Statement st = conn.createStatement();
                        String sql = "select * from local_news_cn_table";
                        ResultSet rs = st.executeQuery(sql);

                        // names of columns
                        Vector<String> columnNames = new Vector<String>();
                        int columnCount = rs.getMetaData().getColumnCount();
                        for(int column = 1; column <= columnCount; column++){
                            columnNames.add(rs.getMetaData().getColumnName(column));
                        }

                        // data of the table
                        Vector<Vector<Object>> data = new Vector<Vector<Object>>();
                        while (rs.next()){
                            Vector<Object> vector = new Vector<Object>();
                            for(int columnIndex = 1; columnIndex <= columnCount; columnIndex++){
                                vector.add(rs.getObject(columnIndex));
                            }
                            data.add(vector);
                        }
                        data_Table = new JTable(data, columnNames);
                        JTabbedPane tabbedPane = new JTabbedPane();
                        JPanel panel = new JPanel();
                        JPanel panel2 = new JPanel();
                        JPanel panel3 = new JPanel();
                        tabbedPane.addTab("Tab 1", panel);
                        tabbedPane.addTab("Tab 2", panel2);
                        tabbedPane.addTab("Tab 3", panel3);
                        panel.add(data_Table);
                        main_panel.add(tabbedPane, BorderLayout.CENTER);
//                        scrapy_info_Frame.setContentPane(main_panel);
                        instance.getScrapy_info_Frame().pack();
                        instance.getScrapy_info_Frame().setVisible(true);

                    } catch (SQLException exception) {
                        exception.printStackTrace();
                    }
                }
            }
        });
    }
    public JTable getData_Table(){
        return data_Table;
    }
    public JPanel getMainPanel(){
        return main_panel;
    }
    public JLabel getScrapy_info_Label(){
        return scrapy_info_Label;
    }
    public JTextField getTextField1(){
        return  textField1;
    }
    public JTextField getTextField2(){
        return textField2;
    }
    public JTextField getTextField3(){
        return textField3;
    }
    public JTextField getTextField4(){
        return textField4;
    }
    public JTextField getTextField5(){
        return textField5;
    }

}
